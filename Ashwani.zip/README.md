# Todo-List-App

### Building a Todo List App from Scratch | HTML, CSS, JavaScript 

